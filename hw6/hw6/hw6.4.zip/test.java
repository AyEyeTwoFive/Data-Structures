package hw6;

import exceptions.EmptyException;
import exceptions.PositionException;
import hw5.List;
import hw6.Position;
import hw6.LinkedList;
import java.util.ArrayList;
import java.util.Comparator;

public class test {

    /* Testing Previous method exception in linked list
    public static void main(String[] args) {
        LinkedList<String> list = new LinkedList<String>();
        Position<String> one = list.insertFront("One");
        Position<String> two = list.insertFront("Two");
        System.out.println(list.first(two));
        Position<String> beforeTwo = list.previous(two);
    }*/

    public static void main(String[] args) {
        /*ListPriorityQueue<String> unit = new ListPriorityQueue<String>();
        unit.insert("Paul");
        unit.insert("Peter");
        System.out.println(unit.list.toString());
        System.out.println(unit.best());
        unit.remove();
        System.out.println(unit.list.toString());
        unit.remove();
        System.out.println(unit.list.toString());*/

    }

}

